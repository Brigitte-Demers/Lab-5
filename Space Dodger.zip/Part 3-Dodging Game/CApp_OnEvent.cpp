#include "CApp.h" // Includes the CApp header file.

void CApp::OnEvent(SDL_Event* Event)
{
	switch (Event->type) 
	{
	case SDL_QUIT:
	case SDL_KEYDOWN:
		Running = false; 
		break;
	case SDL_MOUSEMOTION:
		PlayerCharacter.position.x = Event ->motion.x;
		break;
		// Controls the player character with the mouse.







		// What is happening?
	//case SDLK_DOWN:
	//	int i = 0;
	//	for (i = 0; i < NUM_SPRITES; ++i)
	//	{
	//		allmissiles[i].velocity.y = MAX_SPEED + 3;
	//	}
	//	break;
    }
}
