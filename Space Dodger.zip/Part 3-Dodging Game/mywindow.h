#ifndef MYWINDOW_H
#define MYWINDOW_H

#define WINDOW_WIDTH    800
#define WINDOW_HEIGHT   600

const int window_w = WINDOW_WIDTH;
const int window_h = WINDOW_HEIGHT;

#endif